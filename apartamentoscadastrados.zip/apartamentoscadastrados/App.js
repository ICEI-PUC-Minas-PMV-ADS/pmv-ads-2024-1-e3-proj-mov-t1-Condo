import React from 'react';
import {View, Text} from 'react-native';

import ApartamentosCadastrados from './src/pages/ApartamentoCadastrados'

const App = () => {

return (

<ApartamentosCadastrados />

);

}

export default App;