import React from 'react';
import {View, Text} from 'react-native';

const ApartamentosCadastrados = () => {

return (

<View style={{flex:1, alignItems:'center', justifyContent:'center'}}> 

<Text> Apartamentos Cadastrados </Text>

</View>

);

}

export default ApartamentosCadastrados;